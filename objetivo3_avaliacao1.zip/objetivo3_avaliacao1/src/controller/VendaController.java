package controller;

import model.*;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

public class VendaController {
    public static void main(String[] args) {
        double total;
        double totalFornecido = 0.0;

        Fornecedor fornecedor1 = new Fornecedor("07.190.936/0001-71", "936", "Jo");
        Fornecedor fornecedor2 = new Fornecedor("48.343.026/0001-69", "026", "Ana");

        Vendedor vendedor1 = new Vendedor(1, "Silvia", "Rua: Sete", "Bom Jesus", "83534433", "Pelotas", "RS", "51");
        Vendedor vendedor2 = new Vendedor(2, "Jonas", "Rua: Oito", "Areal", "47745412", "Pelotas", "RS", "92");

        Pedido pedido1 = new Pedido(1, new GregorianCalendar(2022, Calendar.APRIL, 12,11,00), 20.00, vendedor1);
        Pedido pedido2 = new Pedido(2, new GregorianCalendar(2022, Calendar.SEPTEMBER,10, 12,00), 60.00, vendedor2);

        Produto produto1 = new Produto(1, "Modem", 1000, 400.00, fornecedor1);
        Produto produto2 = new Produto(2, "HD", 2000, 300.00, fornecedor2);

        Item item1 = new Item(1, 5.00, 100, produto1);
        Item item2 = new Item(2, 3.00, 200, produto2);

        System.out.println("\n Vendas:");
        produto1.getItems().add(item1);
        produto2.getItems().add(item2);
        pedido1.getItems().add(item1);
        pedido2.getItems().add(item2);
        vendedor1.getPedidos().add(pedido1);
        vendedor2.getPedidos().add(pedido2);

        System.out.println("\n Estoque:");
        produto1.setQuantidade(produto1.getQuantidade()-1);
        produto2.setQuantidade(produto2.getQuantidade()-1);

        System.out.println("\n Vendas 1: ");
        System.out.println(vendedor1.getPedidos());
        System.out.println("\n Vendas 2: ");
        System.out.println(vendedor2.getPedidos());

        Produto produto3 = new Produto(3, "Tv", 1, 1000.00, fornecedor1);
        Produto produto4 = new Produto(4, "Som", 1, 80.00, fornecedor2);

        total = produto3.getPreco() * 50;
        produto3.setQuantidade(produto3.getQuantidade() - 1);
        Fornecimento forneciment1 = new Fornecimento(new GregorianCalendar(2022, Calendar.MARCH, 20, 8, 0), total, fornecedor1, produto3);

        total = produto4.getPreco() * 50;
        produto4.setQuantidade(produto4.getQuantidade() - 1);
        Fornecimento forneciment2 = new Fornecimento(new GregorianCalendar(2022, Calendar.MARCH, 20, 8, 0), total, fornecedor2, produto4);

        List<Fornecimento> fornecimentos = new ArrayList<>();
        fornecimentos.add(forneciment1);
        fornecimentos.add(forneciment2);
        System.out.print("\n Lista de fornecimentos: ");
        System.out.println(fornecimentos);

        for (Fornecimento fornecimento : fornecimentos) {
            totalFornecido += fornecimento.getValorTotal();
        }
        System.out.print("\n Total fornecido: " + NumberFormat.getCurrencyInstance().format(totalFornecido));

        if (produto1.getQuantidade() < 0 || produto2.getQuantidade() < 0) {
            verifica();
        }
    }

    //Objetivo 4 Classe de Exceção
    private static void verifica() {
        mythrowException();
    }

    private static void mythrowException(){
        try {
            System.out.println("Erro, estoque insuficiente.");
            throw new EstoqueInsuficienteException();
        } catch (EstoqueInsuficienteException e) {
            e.printStackTrace();
        } finally {
            System.err.println("Executado classe exceção");
        }
    }

    static class EstoqueInsuficienteException extends Exception {
        public EstoqueInsuficienteException() {
            super("Erro, estoque insuficiente.");
        }
    }

}

