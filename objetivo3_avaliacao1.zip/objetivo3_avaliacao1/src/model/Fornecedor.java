package model;

import java.util.ArrayList;
import java.util.List;

public class Fornecedor {
    private String cnpj;
    private String contato;
    private String nome;
    private List<Produto> produtos = new ArrayList<>();

    public Fornecedor(String s2, String s1, String s) {
        super();
    }

    public Fornecedor(String cnpj, String contato, String nome, List<Produto> produtos) {
        super();
        this.cnpj = cnpj;
        this.contato = contato;
        this.nome = nome;
    //  this.produtos = produtos;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getContato() {
        return contato;
    }

    public void setContato(String contato) {
        this.contato = contato;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Produto> getProdutos() {
        return produtos;
    }

    public void setProdutos(List<Produto> produtos) {
        this.produtos = produtos;
    }

    @Override
    public String toString() {
        return "\nFornecedor{" +
                "cnpj='" + cnpj + '\'' +
                ", contato='" + contato + '\'' +
                ", nome='" + nome + '\'' +
        //      ", produtos=" + produtos +
                '}';
    }
}
